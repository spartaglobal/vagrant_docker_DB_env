--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1 (Debian 12.1-1.pgdg100+1)
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE imdb;
--
-- Name: imdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE imdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE imdb OWNER TO postgres;

\connect imdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: moviedata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.moviedata (
    movie_id integer NOT NULL,
    movie_title character varying(100),
    duration bigint,
    color character varying(20),
    director_name character varying(50),
    actor_1_name character varying(50),
    actor_2_name character varying(50),
    actor_3_name character varying(50),
    gross bigint,
    genres character varying(100),
    plot_keywords character varying(200),
    language character varying(50),
    country character varying(50),
    content_rating character varying(10),
    budget bigint,
    title_year integer,
    imdb_score real
);


ALTER TABLE public.moviedata OWNER TO postgres;

--
-- Name: moviedata_movie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.moviedata_movie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.moviedata_movie_id_seq OWNER TO postgres;

--
-- Name: moviedata_movie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.moviedata_movie_id_seq OWNED BY public.moviedata.movie_id;


--
-- Name: moviedata movie_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moviedata ALTER COLUMN movie_id SET DEFAULT nextval('public.moviedata_movie_id_seq'::regclass);


--
-- Data for Name: moviedata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.moviedata (movie_id, movie_title, duration, color, director_name, actor_1_name, actor_2_name, actor_3_name, gross, genres, plot_keywords, language, country, content_rating, budget, title_year, imdb_score) FROM stdin;
\.
COPY public.moviedata (movie_id, movie_title, duration, color, director_name, actor_1_name, actor_2_name, actor_3_name, gross, genres, plot_keywords, language, country, content_rating, budget, title_year, imdb_score) FROM '$$PATH$$/2907.dat';

--
-- Name: moviedata_movie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.moviedata_movie_id_seq', 5043, true);


--
-- Name: moviedata moviedata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moviedata
    ADD CONSTRAINT moviedata_pkey PRIMARY KEY (movie_id);


--
-- PostgreSQL database dump complete
--

